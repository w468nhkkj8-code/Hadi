# FLOW Station Inspection — IT handover

Release **3.5.14** · 19 November 2026 · Prepared by **Abdulhadi Obaid Alanazi**.

Version 3.5.14 separates sign-in, session permissions and account administration. Cleaning archive navigation now changes the visible page after the request succeeds. CX submissions, photo evidence, reports and Excel export have dedicated source modules. See it/CODE_MAP.md for their paths.

FLOW 3.5.14 pins Next.js and its lint configuration to 16.4.6. The CX styles are grouped by task in app/cx-styles/. Their import order is defined in app/cx.css.

This release corrects the rating scales used to reconstruct historical Cleaning scores. CX automatic refresh waits for the active report list request, which has a 20-second deadline.

Current unified service: https://f5-station-inspection-20261029.wm58m45p9t.chatgpt.site/

This handover contains the application source, dependency lock, seven database migrations, private-evidence storage integration, test suites, deployment utilities and operating instructions. The application has Cleaning and CX workspaces, four staff roles and one Owner. The existing service address is unchanged.

## Start here

1. Read [CODE_MAP.md](CODE_MAP.md) to locate each feature and its source files.
2. Read [DEPLOYMENT.md](DEPLOYMENT.md) before installing on company infrastructure.
3. Read [OPERATIONS.md](OPERATIONS.md) for backup, migration, restore and rollback.
4. Read [ACCESS_AND_OWNERSHIP.md](ACCESS_AND_OWNERSHIP.md) for role boundaries and ownership.
5. Read [API_REFERENCE.md](API_REFERENCE.md) and [VERIFICATION.md](VERIFICATION.md) for interfaces and repeatable checks.

The ZIP includes the modular source, matched Worker build and verification results in [RELEASE.json](../RELEASE.json). Preserve the directory structure so imports, protected page generation and tests continue to work.

## What IT must provide

- A designated technical administrator and an approved hosting account.
- A Cloudflare Workers-compatible runtime with D1 binding `DB` and private R2 binding `BUCKET`, or an explicitly engineered equivalent.
- An approved HTTPS hostname, DNS control and runtime secret management.
- An agreed data/evidence migration and restore plan if moving the existing service.
- Staging acceptance with real company devices, sample data and the designated Owner before cutover.

This is a server-backed application. Uploading the HTML or changing the domain alone does not move the database, evidence or accounts. IIS/Nginx/ordinary static hosting needs application/runtime adaptation; no such adaptation is claimed here.

## Release changes

Release 3.5.10 synchronizes the health endpoint with the package version and verifies the result in the built Worker test. The operations guide identifies the stored CX attachment key used for evidence backup and restore.

Release 3.5.9 labels monthly station averages and individual visit scores in CX Reports. Use **View remaining stations** to see every ranked station and **View visits** to open that station's evaluations for the selected month. Ranking includes all submitted visits across all lines. No schema change is required.

Release 3.5.8 adds a collapsible Station of the Month section and a Ranking month selector to revisit earlier months. Historical rankings are calculated from saved CX evaluations. No schema change is required.

Release 3.5.7 compacts the two Cleaning banners on desktop, makes the highest monthly CX average the first-place result at any percentage, and supports three photos per item and three overall. Each image retains its item association in the CX gallery and workbook. This release requires no new migration.

The browser modules `js/script.js` and `js/auth.js` provide the role-based navigation and sign-in request contract. Edit `lib/auth.ts` and the account service to replace the identity provider or storage on the server. Existing accounts and credential hashes reside in the configured database.

Release 3.5.6 updates React, React DOM and React Server Components to 19.2.9, verifies current Owner authority during account changes, restores sign-in after recovery from an expired temporary password, and commits report deletion with its audit record.

The current build includes the English date, time and month pickers in both Cleaning and CX. These controls submit the existing ISO values and use Riyadh time for defaults.

The first-owner setup endpoint now refuses a missing, malformed, expired, infinite or fractional expiry. A future safe-integer Unix timestamp in milliseconds and the matching setup-code digest are both required. Existing installations with an Owner stay closed to setup. Runtime and build dependencies were updated in response to the registry security audit; the lockfile and tested overrides are included.

Clean-extraction verification also identified an unnecessary build dependency on an old standalone PDF. That historical guide is now optional, so the maintained IT source package builds without obsolete documentation. The current instructions are the separate files in this directory.

Release 3.5.3 appends migration 0006, adding a nullable deletion timestamp for delegation entries. The Owner can remove an entry after revocation, with confirmation and an audit trail. Accounts, credentials, reports, branding and the unified address are retained.

## Contents and privacy

Production passwords, session cookies, setup codes, secret values, production database backups and private CX photos are not bundled. IT must transfer any required live backup through an authorized private process. Synthetic test credentials are deliberately local fixtures and are never production credentials.

`application/reference/` contains retained test references, not the deployable application. `application/dist/`, `generated/` and `dist/` are build outputs. Deploy only the Worker plus its matched assets, with the database and private evidence bindings configured.

The release record lists the checks completed for this package. Follow the staging acceptance steps in [VERIFICATION.md](VERIFICATION.md) on company devices and infrastructure.
