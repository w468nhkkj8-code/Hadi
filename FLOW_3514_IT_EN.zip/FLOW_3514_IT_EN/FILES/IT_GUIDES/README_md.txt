# Flow — Station Inspection with application accounts (3.5.14)

Version 3.5.14 separates sign-in, session permissions and account administration. Cleaning archive navigation now changes the visible page after the request succeeds. CX submissions, photo evidence, reports and Excel export have dedicated source modules. See it/CODE_MAP.md for their paths.

FLOW 3.5.14 pins Next.js and its lint configuration to 16.4.6. The CX styles are grouped by task in app/cx-styles/. Their import order is defined in app/cx.css.

This version uses the saved item rating scale when reconstructing historical Cleaning scores. CX automatic refresh waits for the current report list request to finish. An unresponsive request times out after 20 seconds and can be retried. This release uses the existing database schema.

Release 3.5.10 reads the version returned by `/api/health` from `package.json`. The built Worker test verifies that they match. The IT handover documents the attachment IDs used for private CX photo storage and how to check the packaged Worker. No database migration is required.

Release 3.5.9 labels monthly station averages and individual visit scores in CX Reports. Station of the Month shows three leaders and lets supervisors expand the remaining standings or open a station's visits for the selected month. Report cards and summary figures follow the active filters while the month ranking continues to use all lines. No database migration is required.

Release 3.5.8 adds Show ranking and Hide ranking to Station of the Month in CX Reports. The Ranking month selector reopens the results from submitted CX evaluations for past months. It shares the month with the report filters. The collapsed section shows the selected month and its leading station when available.

Release 3.5.7 compacts both Cleaning banners on desktop. CX accepts up to three photos per item and three overall, with per-photo removal, private viewing and Excel export. Station of the Month ranks the highest station average first at any percentage. The portal's sign-in requests and navigation are in `js/auth.js` and `js/script.js`. No database migration is required.

Release 3.5.6 checks current ownership when account permissions are written. Recovery through a valid legacy reset link clears expired temporary-password state and revokes prior sessions. Report deletions and their audit records commit together. React, React DOM and the React Server Components package are pinned to 19.2.9.

Release 3.5.5 uses English date, time and month controls in Cleaning and CX. The Evaluation Month and Comparison Month filters use English month names, and the Cleaning form uses English date and time values with Riyadh defaults in the pickers.

Release 3.5.4 gives CX Visit Date and Visit Time English date and time pickers. The form displays dates as `11 Nov 2026` and times as `06:16 AM` in Riyadh time, with the existing ISO date and 24-hour time values used for submission.

Release 3.5.3 lets the Owner delete a revoked Account-Creation Access entry from the Delegations list. The server requires explicit confirmation, a revoked delegation and a current active Owner at the write. The entry is soft-deleted, its audit trail is retained, and the person's account, credentials and inspection reports are unchanged. The UI prevents delayed list responses from restoring a removed entry. Migration `0006_revoked_delegation_cleanup.sql` adds one nullable `deleted_at` column; existing records and access remain unchanged until the Owner acts.

Release 3.5.2 keeps the four-colour card accents inside each rounded card using its background instead of an overlaid stripe. Shared form controls and CX filter/visit grids prevent date and select fields from overlapping on narrow screens. CX Reports adds Track Inspection: an exact saved Inspection Code opens its authorized detail independently of month/line/station filters, using the existing protected API. No database, permission, account, report or public-URL change is required.

**IT handover:** start with [it/README_EN.md](it/README_EN.md). The code map, portable deployment, backup/restore, API, ownership boundaries and verification instructions are maintained separately in `it/`.

The 3.5.1 dependency lock includes reviewed security updates for the runtime and build tooling. Keep the `pnpm-workspace.yaml` overrides with the lockfile. The dated handover QA report records the actual audit and test results.

Release 3.5.1 rejects first-owner setup when `OWNER_SETUP_EXPIRES` is missing, malformed, fractional, infinite or expired. Setup requires a safe integer Unix timestamp in milliseconds strictly later than the current time and the existing matching setup-code hash. Once an owner exists, setup remains closed. Regression coverage runs against real authentication/SQLite and the built Worker with isolated D1: `node tests/setup-expiry.mjs` and `node tests/setup-expiry.mjs --worker`. No account, credential, report or schema migration is required.

Release 3.5.0 embeds the saved CX item and overall photos in a separate Photo Evidence worksheet. Each photo is captioned with the existing immutable inspection code and reference item; the same code appears in the employee receipt, CX report cards/details, every exported item and the downloaded filename. Summary, ratings and remarks remain in their existing sheets. Exports read private R2 evidence only after the existing CX Administrator/Owner checks and fail clearly if a saved photo cannot be included; photos and source records are never rewritten. JPEG/PNG evidence is embedded directly, and the camera/library picker continues preparing JPEG uploads. No database migration is required.

Release 3.4.2 makes every permanent **Account-Creation Access** grant include all four non-owner account types: Cleaning Employee, Cleaning Administrator, CX Employee and CX Administrator. Existing permanent grants receive the same effective scope, including earlier grants stored with only one selected type. The Owner selects the administrator in **User Management**; there is no account-type restriction selector. No new administrators receive access automatically.

Eligibility remains limited to active Cleaning or CX Administrators who have set their personal password. The administrator retains their normal department workspace and receives **Add User** on the same unified link. New access is immediate and permanent until revoked. It provides no Owner user list, password recovery, user-permission updates or ownership controls. Created accounts have their own assigned role and do not inherit creation access.

Suspension, changing the delegate to an employee and ownership transfer permanently revoke affected grants. Account creation rechecks current database authorization inside the user INSERT after password hashing. Existing time-limited records retain their previous role restrictions and dates; saving the administrator's access again replaces them with permanent all-account access. This release changes no database schema.

Validate with `node tests/delegation.mjs` and, after a production build, `node tests/delegation-worker.mjs`. The suites exercise the upgrade of an earlier single-type permanent grant, successful creation of all four roles, Owner-only endpoint denial, new-user isolation, revocation, demotion races, legacy grants and ownership transfer using isolated accounts.

Release 3.3.2 uses **Station Inspection** consistently in the shared page header, inspection document titles and daily Excel report title.

Release 3.3.1 sets the public page title and Open Graph / Twitter sharing metadata to **Flow — Station Inspection**, with the official FLOW logo as the preview image. The existing unified URL is retained.

Release 3.3.0 provides four ordered account types in Add User and existing-account role selectors: **Cleaning Employee**, **Cleaning Administrator**, **CX Employee**, **CX Administrator**. Cleaning accounts use the original inspection/report workspaces; CX accounts use CX Evaluation/CX Reports. The owner retains all workspaces and exclusive account management. Department isolation is enforced on APIs, photo evidence, exports and protected documents as well as navigation. User lists follow the same department/role order.

Stored `employee`/`admin` roles now display as Cleaning Employee/Administrator; `cx_employee`/`cx_admin` are the new CX roles. Existing account role values, credentials and saved reports are not rewritten. The owner can explicitly change an account's department from User Management; changes revoke existing sessions. Both departments support temporary passwords, required first password change, suspension, recovery and deletion of stopped accounts. The current owner may transfer ownership to either administrator type using the existing password/confirmation checks; the former owner takes that administrator's department. No production ownership transfer occurs during publication. No schema migration is required because account roles use an existing text column.

Release 3.2.0 adds **CX Evaluation** for employees/owner and **CX Reports** for admins/owner within the same signed-in root page. The existing inspection and management workspaces remain available. The SOM / CX monthly checklist has 20 required ratings (reference items 6–25, 1–5 points each, maximum 100), organized into six sections. Every item includes optional remarks and a camera/photo upload. Review includes required Evaluator Comments, optional Issues Identified and Immediate Actions Required, and an additional overall photo.

CX data uses the new `cx_evaluations` D1 table; evidence uses the private `BUCKET` R2 binding. Sites provisions the binding declared in `.openai/hosting.json` and applies append-only migration `0003_adorable_reaper.sql` before publishing. Ratings, evaluator identity, station/line and scores are validated on the server. Photos retain their item association and require an authorized session to view. Retries reuse the same evaluation reference, and incomplete uploads stay out of reports.

The camera/library picker prepares JPEGs up to 1,600 pixels on their longest edge. Each item and the overall visit section accept up to three photos. The server permits 2 MiB per saved image and 16 MiB per multipart submission. Photo and remarks fields are optional. All 20 ratings and Evaluator Comments are required. CX Reports supports monthly/line/station filters, 20-record pages, full details, protected photo viewing, Excel export and individual confirmed soft deletion.

Run `node tests/cx.mjs` for authentication/SQLite/evidence integration and, after building, `node tests/cx-worker.mjs` for the production Worker with isolated D1 and R2. These tests do not contact or write production data.

Release 3.1.4 displays “Prepared by Abdulhadi Obaid Alanazi” without an employee number in the shared portal footer and both workspaces. Account headers show the signed-in person's name, employee number and role.

Release 3.1.2 applies the FLOW palette: Black #000000, Deep Green #0F493D, Gold #FFCC00, Yellow #FFFF00, Green #00B050 and Purple #7030A0. The portal and both workspaces use white surfaces, accessible dark text and a four-colour accent on each section. Lines 3/4/5/6 use Gold/Yellow/Green/Purple respectively. Daily and monthly Excel workbooks use Lato and the FLOW theme. The typography specification for future Word files is Lato and for presentations is Calibri. Existing logo artwork and the blue dashboard banner are retained.

Release 3.1.1 groups numbered entrances, concourse levels and platforms in sequence in the form, management details and Excel exports. Visible item numbers follow that sequence; source question IDs, saved answer associations and all scoring weights remain stable.

Release 3.1.0 provides an English interface, accessible labels, validation and access messages, and English daily/monthly Excel headings. Layout and dates use left-to-right English formatting with Riyadh time. Account names, inspection IDs, historical results, and user-entered remarks retain their stored values.


Release 3.0.12 expands Line 3 to four entrances, with seven at 3B2. New entrances repeat all 13 items of Entrance 3 (26 maximum points per entrance). The complete maxima are 384 / 184 questions and 462 / 223 questions respectively; NA still removes only the relevant item weights. Trusted variants are derived from the retained base in `template-variants.json` by a shared pure builder used by the form build and server. Each new report records the checklist revision and entrance count. Historical saved payloads and their targets are read as stored.

Release 3.0.11 also compacts the management shell for both admin and owner: a short header, single scrolling mobile navigation row and no duplicate page title. The original blue management banner is retained. Dashboard helper paragraphs are removed; status, refresh and sound controls share a compact toolbar. Receipt lookup stays inline on phones, and the dashboard uses a wider desktop canvas. Error/reconnection notices, report filters, scores, exports, confirmations and server permissions are retained.

The hosted app now has employee-number/password login, owner-created accounts with temporary passwords, employee/admin roles and a protected D1 report store. Microsoft SSO is not active. No visitor needs ChatGPT when the hosting audience permits the app's own login page.

Release 3.0.10 compacts the employee header, account navigation, live-score strip and fixed submit bar, and enlarges rating touch targets. The station-performance table adds a compact scrolling Delete column for the station's latest inspection. The confirmation identifies the station, inspection date and exact inspection ID; the existing server-authorized single-record soft delete is reused. Pending catalogue/month reads are invalidated after a confirmed deletion so a stale snapshot cannot restore the deleted row. The existing Site identity and unified URL are retained.

Start with [ACCOUNTS_IT.md](ACCOUNTS_IT.md) for roles, account activation, security boundaries, file responsibilities and runtime settings. The owner creates their own password at `/setup` using a separately delivered, expiring setup code. There are no default production passwords or public signup routes.

## Routes

| Route | Purpose |
|---|---|
| `/` | Unified sign-in, first-password change and role-specific workspace; owner switches between reports, inspection form and account management here |
| `/login` | Compatibility redirect to the shared root |
| `/setup` | Initial owner setup, closes when an owner exists |
| `/activate` | Compatibility for previously issued single-use links |
| `/accounts`, `/employee`, `/management`, `/password` | Authorized compatibility redirects to a section of the root; the section fragment is consumed on entry |
| `/workspace/employee` | Internal same-origin form document, restricted to employee/owner |
| `/workspace/management` | Internal same-origin report document, restricted to admin/owner |

Workspace sections switch in place without changing the address. Only owners see user-management and both work sections; employees see the inspection form, and admins see reports. The legacy form and report documents run in a full-height same-origin frame so sticky scores, fixed submission controls, scrolling, downloads and existing scripts keep working. Each document and API checks the session independently. The work documents allow same-origin framing only, never external framing. Expired frame sessions return the top-level portal to shared sign-in. Direct document navigation redirects to the root. No schema migration, live account changes or report changes are required.

The owner selects a separate temporary password for each new account; staff enter it on `/` and must choose a different private password before any report/form access. Temporary credentials expire after 72 hours. Successful completion ends all temporary sessions; the user signs in with the new password on that same page. Existing accounts retain their current passwords. No new activation link is generated by the owner interface.

The earlier HTML employee/admin paths redirect through the same server authorization checks. Selecting native ChatGPT “invite only” adds its own ChatGPT sign-in gate again; use the app's account management for invitations.

## Implementation and checks

This is the supplied Vinext/Cloudflare Worker starter with D1, Better Auth 1.7.12 and Drizzle. The existing `application/` contains employee 2.6.9 / management 2.22 source: trusted station data, scoring, monthly comparisons, pagination and Excel export. The root build prepares protected, same-origin versions; do not deploy `application/dist` directly because that bypasses the application server.

Run `npm run build` through the Sites build helper. For local work, use the declared package manager and the checked-in lock. Generate schema migrations with `npm run db:generate`; apply pending local migrations before starting the managed preview. Never modify applied migrations.

Run `node tests/accounts.mjs` for real SQLite/auth integration. After building, run `node tests/worker.mjs` for the built Worker in workerd with isolated D1. Existing scoring, Excel and submission/receipt regression tests remain under `application/tests/`.

Production secrets are configured through Site runtime settings, not Git or the hosting manifest. Generated protected pages and dependencies are ignored. Authored code, migration SQL and migration metadata are version-controlled.

History is copied read-only from the old prototype and verified by per-report content hashes. Old answers, weights, targets and timestamps are retained. The previous Supabase API/Netlify deployments are independent services; IT must separately restrict/retire them after migration approval. New submissions use D1. No automatic report deletion or email delivery is enabled.
