# IT source delivery copy | 2.24.2-it.2 | 26 October 2026

Start with START_EN.txt and SOURCE_MAP.md. Project attribution stays visible on both pages through a finished raster image; application text source contains no literal attribution name or employee number. This does not prevent an editor from removing or replacing that image. Employee 2.6.9 and management 2.22 preserve all runtime behavior. Existing guides below remain historical baseline documentation.

---

# Current management performance: 2.22

Source checkpoint 2.24.2. Read PERFORMANCE_UPDATE_20261025.md for this focused update and current verification. The full guide below remains the 2.24.1 baseline.

# F5 Developer Guide

Handover 2.24.1 | 25 October 2026 | Employee 2.6.9 | Management 2.21.1

Abdulhadi Obaid Alanazi | EMP No. 1006992

## Technical handover | release 2.24.1

F5 Station Inspection Suite. Employee CSF5 2.6.9, management MNF5 2.21.1 and complete source/handover 2.24.1. Prepared on 25 October 2026. This package includes the latest management author-credit placement.

Prepared by Abdulhadi Obaid Alanazi, employee number 1006992. This guide explains every application source file, score logic, Excel outputs, integration responsibilities and local verification.

All eight local verification groups passed. A separate authorized test also saved one temporary report to the existing prototype service, read it back with the actual management client, confirmed matching receipt and duplicate rejection, then removed it. Company production and browser acceptance remain pending.

The applications retain their shared prototype connection. Company IT configures the approved service, identity, permissions, hosting and long-term storage. Email copies are optional and inactive.

| Component | Version / scope |
| --- | --- |
| Handover and source | 2.24.1 / package 2.24.1 |
| Employee / management | 2.6.9 / 2.21.1 |
| Current Lines 3, 4 and 6 | 171 items / full maximum 358 |
| Line 5 | 11 unchanged source workbooks / station-specific models |
| Editable application source | 37 individual HTML, CSS, JavaScript and JSON files |
| First read | F5_IT_Start_Here.pdf, then this guide and SOURCE_MAP.md |

## Package and quick start

Keep the complete handover ZIP as the release record. Deploy generated files together on company-approved HTTPS hosting. Keep the editable source in company version control.

Use a company-supported Node.js runtime. This release was checked on Node v24.22.1. package.json declares >=18 as a language baseline, not a support-life promise. No third-party npm dependency or npm install is required.

From Source_Code/F5_Developer_Source run: npm run build; npm test; npm run preview. These are three separate commands. The preview server prints its local URL and serves dist. It is not an authentication or production server.

Opening a preview contacts its configured service. Use an authorized test environment. npm test is isolated from the external service; the separate 25 October prototype check is documented in LIVE_SERVICE_VERIFICATION.json.

| Package item | Purpose |
| --- | --- |
| F5_Station_Inspection_Suite/ | Current CSF5.html, MNF5.html and ITF5.pdf |
| Source_Code/F5_Developer_Source/ | Individual source, tools, tests, docs and reproducible dist |
| Lines_3_4_6/ | Current blank operational reference: 171 items, maximum 358 |
| Line_3/ | Original corrected 352-point input workbook; provenance basis |
| Line_5/ | Eleven original station workbooks, unchanged |
| IT_Integration/ | Contracts, config examples, diagnostic and company acceptance cases |
| VERIFICATION*.json / SHA256SUMS.txt | Test evidence and release file hashes |

## Architecture and editing ownership

The editable master is src. Generated HTML combines ordered classic script fragments, CSS, JSON and embedded banners. These fragments share bindings; they are not independently importable ES modules.

source-manifest.json owns assembly order. tools/build.mjs replaces each token exactly once, validates generated JavaScript syntax and copies approved references to dist. Edit source and rebuild; do not maintain an independently edited deployment copy.

templates.json contains seven canonical models. L3 owns the current common checklist. template-aliases.json maps L346 to L3 at build time, retaining the existing station directory without maintaining a duplicate checklist.

Both applications use the same stations.json. Keep station identities, actual line and template associations consistent. Historical saved records remain independent of future template edits.

| Change needed | Authoritative location |
| --- | --- |
| Employee score calculation | src/employee/scoring.js |
| Current shared checklist / scales | src/employee/data/templates.json, key L3 |
| Station catalogue | src/employee/data/stations.json |
| Monthly comparison | src/management/monthly-scoring.js |
| Monthly four-sheet Excel | src/management/monthly-excel.js and data/excel-template.json |
| Report connection / token bridge | The employee and management config.js files |
| Script order / output paths | source-manifest.json |

## Stations, models and preserved history

There are 47 configured stations. Actual Line 4 and Line 6 identity is retained even where the employee selector uses the combined group. Removed 6D1, 6H2 and P&R Bldg entries remain absent.

All 22 Line 3 stations, eight Line 4 stations and six Line 6 stations use the same current model. Line 5 retains six existing station-specific models across eleven stations. The 5C2 full company target remains 384.

The corrected original Line 3 workbook has 168 items and maximum 352, including one P&R item worth 10. The requested four parking levels replace that single item: 352 - 10 + 4*4 = 358, and 168 - 1 + 4 = 171 items. The current parking display scope is P&R & Washrooms for every level; this wording change does not alter the scales or weights.

reference/Line_3/Checklist_Line_3.xlsx is that untouched input basis. reference/Lines_3_4_6/Checklist_Lines_3_4_6.xlsx is the derived current operational reference. Superseded 343/228-point workbooks exist only under original_workbooks.

Saved historical reports retain their original weights, target and scoring model. Never recalculate old records using the new current checklist.

| Line | Stations | Current behavior |
| --- | --- | --- |
| 3 | 22 | Shared 171-item model; orange status group |
| 4 | 8 | Shared 171-item model; yellow status group |
| 5 | 11 | Existing station-specific models; green group |
| 6 | 6 | Shared 171-item model; purple status group |

## Mixed scales and correct percentage

Every item requires an explicit numeric answer or NA. Earned points = rating / rating maximum * effective item weight. Percentage = total earned / total applicable maximum * 100.

Numeric zero remains in the denominator and can lower the result. NA contributes neither points nor applicable maximum. All NA means unavailable, not a genuine 0%. The live partial score is provisional until all required items are answered.

The original workbook SHA remains provenance. checklist_adjustments records the derived parking change. Each parking source_max_points=10 refers to the original unsplit item; use effective max_points=4 per level for current arithmetic.

Each of the four parking items is P&R & Washrooms — Level 1, 2, 3 or 4. It includes that level’s parking area and washrooms. The existing standard washroom items are preserved. The operational Excel reference carries the same four names.

| Group | Count / scale | Maximum |
| --- | --- | --- |
| Ordinary items | 166 / 0, 1, 2 or NA | 332 |
| Masjid | 1 / 0 through 10 or NA | 10 |
| P&R & Washrooms Levels 1, 2, 3 and 4 | 4 / 0 through 4 or NA each | 16 |
| Full current model | 171 answers | 358 |

Completed examples: full 358/358 = 100%; half 179/358 = 50%; zero 0/358 = 0%. All parking NA and others full: 342/342 = 100%. Parking 0,1,2,NA and others full: 345/354 = 97.4576271186441%. All NA: 0/0, displayed as NA.

## Monthly comparison and station status

The selected calendar month has four fixed periods: days 1-7, 8-14, 15-21 and 22 through month end. The inspection date chooses the period. The latest server receipt selects one report within that period.

Monthly percentage = sum of evaluable period percentages / count of evaluable periods. Missing and all-NA periods are excluded; actual 0% is included. An incomplete month is an available-period average, not a completed four-period score.

Differences are percentage points: later percentage minus earlier percentage. Both adjacent differences and period 4 minus period 1 are reported. A missing endpoint leaves the difference empty.

Station groups stay fixed in Line 3, 4, 5, 6 order with their colors and compact expand/collapse headers. Each station has one current row. A newer station report updates that row and moves it first within the same line.

Daily reports remain the archive. Date/line/station filters and Today/Yesterday/Previous headings belong there. Station status does not duplicate all old reports.

| Period example | Score | Included in mean |
| --- | --- | --- |
| 1: days 1-7 | 50% | Yes |
| 2: days 8-14 | 100% | Yes |
| 3: days 15-21 | 0% | Yes: genuine zero |
| 4: days 22-end | 97.4576271186441% | Yes |
| Arithmetic mean | 61.8644067796610% | 247.4576271186441 / 4 |

## Inspection lookup, save and receipt

The employee save path validates completeness, builds one inspection ID and sends the report. A successful persistence response is shown as Saved. Management confirms Received only after an authorized read returns the same inspection ID.

Same-origin localStorage/BroadcastChannel notices can prompt a refresh, but are not a replacement for server storage or cross-device receipt. Cross-device operation depends on the configured report service and permissions.

After successful management lookup, clearReceiptLookup clears the matching input, its default value and a matching inspection_id URL query. The received result, internal tracked ID and report/station navigation remain available.

Background checks do not refill the input. A consumed received ID is not restored at startup or back-forward cache return. A newer unfinished lookup draft is preserved. Unknown/denied reads do not claim receipt.

Failed saves retain answers and the inspection ID. After an uncertain timeout, check the same ID before retrying. Server-side uniqueness must prevent a duplicate report.

A background receipt poll shares the current lookup request rather than replacing its generation. Slow service responses can complete, and a foreground lookup always releases its button. New typed IDs and stale responses remain isolated.

| Behavior | Code |
| --- | --- |
| Submit / error state | employee/submission-flow.js and submission-service.js |
| ID and local notifications | employee/helpers.js and runtime.js |
| Successful lookup reset | management/receipt-tracking.js |
| Reopen / back-forward | management/bootstrap.js |
| Keep scrolling position | management/refresh.js |
| Optional mail copies | employee/email-service.js; bounded independently after the report is saved |

## Archive loading and long-term operation

The daily archive loads a maximum of 20 compact summaries per displayed page. For current reports, the first-answer metadata supplies exact percentage and problem count, without downloading all 171 answers for every card.

Complete saved answers are fetched when the user opens Full Report or Problems, or exports Excel. Simultaneous requests for the same inspection share one load. The full-detail cache holds at most 12 reports. A daily export always fetches complete answers before building its workbook.

Historical reports without exact percentage metadata still use their full saved weights for accurate reconstruction, then return to compact summaries. A missing historical problem count is not displayed as zero; it is filled when the report is opened.

Unchanged background polls do not rebuild cards or redownload full answers. The daily archive starts independently of slower station-catalogue requests. Manual navigation can preempt a background read, and cancelled queued requests are removed.

The browser stores only small profile, filter, panel and receipt preferences. It does not persist the complete archive in localStorage. The dashboard never deletes reports automatically; durable storage, retention and backup belong to the company report service.

| Bound | Value |
| --- | --- |
| Visible archive page | At most 20 compact summaries |
| Full-detail cache | 12 reports, fetched on demand |
| Known arrival IDs / saved scroll entries | 256 / 128 |
| Archive cursor history / request concurrency | 64 / at most 6 |
| Month data | Four selected-period summaries per station, plus a latest-station catalogue capped at 100 |
| Month revalidation | New-arrival invalidation; five-minute fallback; on-demand load while expanded |

## Reliability and presentation | release 2.24.1

This release fixes two reproducible waiting states. Background receipt polling could invalidate a manual lookup and leave its button disabled. Optional mail token lookup or response-body parsing could wait outside the deadline after the report was saved.

Receipt reads now coalesce while the same request is active. The optional mail module has one 30-second deadline covering company identity, fetch and JSON consumption. A timed-out identity lookup cannot send a late mail request. Mail remains inactive in the supplied configuration.

The existing archive performance repairs remain: 20 compact summaries per page, full answers on demand, a 12-report detail cache, at most six requests, hidden-page polling suppression and unchanged-view retention. The complete archive remains in the service.

The employee author credit is now a compact side signature within the inspection-reference card. On narrow displays it wraps into a small lower row. It is removed from beneath the banner. Telephone auto-detection is disabled for the employee number.

P&R & Washrooms is shown for all four levels in Lines 3/4/6. Scales, NA, target maximum 358 and item count 171 are unchanged. The derived workbook has four matching labels; all 347 formulas are preserved.

Management attribution is now a compact footer at the lower right of dashboard content, below the daily archive. A thin divider and muted text separate it from inspection controls. It wraps on narrow displays. The banner-area attribution is removed; management functions and configuration values are unchanged.

| Repair | Evidence |
| --- | --- |
| Receipt concurrency | The regression test failed on the old source (two competing reads) and passes after request sharing. |
| Optional mail deadline | The old source failed the delayed-token test. Current tests cover identity, transport, JSON, abort and late-token behavior. No mail was sent. |
| Real prototype transaction | HTTP 201 save; exact-ID read and receipt; HTTP 409 / 23505 duplicate rejection; temporary report removed. |
| Browser boundary | Controlled DOM and native HTTP tests do not prove actual browser layout, CORS or company role enforcement. |

Company IT still validates supported browsers, Microsoft Excel, separate-device use, permissions, real service load and backup restoration.

## Excel: four monthly sheets

Station status exports one XLSX with four sheets. The first two sheets retain formulas, numeric dates/times and formatting. The third and fourth sheets retain filters, frozen panes, wrapped details and typed numeric ratings.

The cleaning-standard/criterion column is removed from monthly details and daily single-report Excel. It remains in the on-screen checklist and stored JSON as inspection definition; removing an export column does not erase history.

Monthly detail columns A:L: period, inspection ID, employee, inspection date, question number, section, item, rating, earned points, effective maximum, source maximum and remarks.

IDs and employee numbers remain text. Ratings and points are numbers, including mixed scales. Remarks beginning with a formula-like character remain text. The original source maximum is provenance only, especially for the split parking item.

| Sheet | Contents |
| --- | --- |
| 1. Employee information | Submitter, employee no., inspection ID, dates/times, contacts and general remarks for each selected period. |
| 2. Monthly performance | Four period scores, adjacent changes, sum/count, monthly mean and period 4 minus period 1. |
| 3. Station problems | Zero ratings or written item remarks, plus written general remarks from selected inspections. |
| 4. All checked items | All saved answers from selected inspections, including NA and remarks. |

Daily single-inspection export remains a separate two-sheet workbook. The current blank operational reference is an input template, not a saved report. It contains no fabricated employee or inspection result.

## Report API and exact metadata

The submitted object has exactly 12 top-level keys. id and created_at are server outputs. Display line, inspection date, contacts and exact scores live in answer metadata, not new POST columns.

Current database integer columns may store rounded score_achieved and score_percent. Accurate comparisons use answers[0].score_percentage_exact and score_applicable. Preserve all metadata; rounded scalar fields alone are insufficient.

Each mixed-scale answer includes rating_scale. Parking rows also carry parking_level, original question/item provenance, source_max_points and scoring_method=parking-level. Validate the approved 171-answer model and per-item numeric range server-side.

All-NA has score_applicable=false. Historical reports use their saved legacy weights/section model. New mixed-scale records require their exact metadata to remain intact.

| Field group | Contract |
| --- | --- |
| Identity | inspection_id, station, employee_name, employee_no |
| Times | start_time, end_time |
| Result | score_achieved, target_score, score_percent |
| Completeness | answered_count, total_items |
| Details | answers JSON array, ordered items; first item carries report metadata |
| Server only | id, created_at; trusted receipt timestamp and unique inspection_id |

Complete field, projection and error details: IT_Integration/data-contract.md. No production migration or credentials are supplied. The live prototype test does not establish company authorization or security.

## Company service and access integration

Current request wrappers use PostgREST-compatible routes. A different company platform needs a compatible adapter or deliberate wrapper changes. Configure both pages to the same approved service.

Use a browser-safe application key. Company user identity must come from an approved getAccessToken() bridge returning an API-accepted user JWT. Never place service secrets, mail passwords or a fixed user token in browser files.

IT_Integration includes employee and management configuration examples. Placeholders are intentional and the examples are not auto-loaded. Adapt the source config files, implement identity before startup requests, then rebuild.

Company IT must enforce employee write and management read/delete permissions on the service, validate identity and score inputs, supply durable storage and timestamps, and test allowed and denied cases independently.

Required hosting/API work includes approved HTTPS origins, CORS/preflights, browser-readable Content-Range when counts are supplied, stable ordered paging, JSON metadata projection/filtering and correct one-row delete acknowledgement.

Review indexes against real query plans: unique inspection ID, receipt order, station/receipt order and the validated inspection-date path. Implement retention, backup/recovery, logging and a named support owner.

Optional mail is a separate same-origin, server-owned hook. Its total deadline includes the identity bridge, request and response body. A mail failure must not undo or obscure an already accepted report.

| Optional facility | State |
| --- | --- |
| Email copies | Inactive; configure server-side only if required. Receipt is independent of mail. |
| Read-only diagnostic | Limited connectivity check; does not establish CORS, saving, roles or performance. |
| Acceptance checklist | IT_Integration/acceptance-tests.md; company cases remain pending. |

## Source map | shared and employee

Paths below are relative to F5_Developer_Source. Each file is independently editable. Preserve manifest order and shared bindings, then rebuild and run the local checks.

| Source file | Code / responsibility |
| --- | --- |
| src/index.html | Default entry. Redirects to the employee page; management and IT use their explicit paths. |
| src/employee/CSF5.html | Employee HTML shell. Form markup and build tokens; manifest supplies scripts/styles. |
| src/employee/styles.css | Employee presentation. Responsive form, ratings, messages and submission bar. |
| src/employee/config.js | COMPANY_CONFIG. Report endpoint, public key, version, management URL and optional email hook. |
| src/employee/data/templates.json | L3 and six Line 5 models. Canonical items, weights, scales and provenance. L3 serves Lines 3/4/6. |
| src/employee/data/template-aliases.json | L346 -> L3. Build alias preserves station mapping without duplicate shared data. |
| src/employee/data/stations.json | STATIONS_BY_LINE. Shared station directory used by both applications. |
| src/employee/runtime.js | Submission state / notification. State, submission notices and matching management receipts. |
| src/employee/helpers.js | esc / round2 / makeInspectionId. Escaping, numeric display and client inspection-ID generation. |
| src/employee/station-selector.js | populateStations / selectStation. Station options, actual line identity and selected checklist. |
| src/employee/checklist-view.js | renderChecklist. Individual rating scales, NA and item remarks. |
| src/employee/scoring.js | calc / calcSectionScores. Earned points, effective denominator, exact percent and legacy section weighting. |
| src/employee/results-view.js | update / refreshProblems. Live score, missing answers, problems and submit readiness. |

## Source map | submission and management data

Paths below are relative to F5_Developer_Source. Each file is independently editable. Preserve manifest order and shared bindings, then rebuild and run the local checks.

| Source file | Code / responsibility |
| --- | --- |
| src/employee/submission-service.js | employeeTimedOperation / requestDatabase. Bounds employee identity/save requests and normalizes save errors. Mail lives separately in email-service.js. |
| src/employee/email-service.js | requestEmailCopies. Optional same-origin mail after saving; normalized recipients and one identity/fetch/JSON deadline. |
| src/employee/submission-flow.js | Submit handler. Required answers, exact metadata and problem_count in the same 12-field POST. |
| src/employee/profile-and-start.js | saveProfile / loadProfile. Small profile preferences and new inspection; not archive storage. |
| src/management/MNF5.html | Management HTML shell. Dashboard markup, lower-right attribution footer and build tokens. |
| src/management/styles.css | Management presentation. Compact colored panels, filters, tables and responsive footer attribution. |
| src/management/config.js | MANAGEMENT_CONFIG. Report service settings and optional company token bridge. |
| src/management/state-and-alerts.js | Dashboard state. Loading state, selected filters and user messages. |
| src/management/report-values.js | answersFor / earnedFor / problem. Saved-answer readers, earned points, contacts and problem classification. |
| src/management/receipt-tracking.js | trackInspection / clearReceiptLookup. Exact ID lookup, shared in-flight polling, matching receipt, input reset and navigation. |
| src/management/database-client.js | databaseRequest / cancellable queue. At most six requests, queued cancellation and 30-second identity/fetch/JSON deadlines. |
| src/management/archive-loader.js | loadArchivePage / prepareArchiveSummaries. Twenty compact summaries, coalesced lazy details, legacy precision fallback and bounded caches. |

## Source map | management outputs

Paths below are relative to F5_Developer_Source. Each file is independently editable. Preserve manifest order and shared bindings, then rebuild and run the local checks.

| Source file | Code / responsibility |
| --- | --- |
| src/management/archive-actions.js | deleteInspection / filters. Confirmed one-report daily deletion and filter preferences. |
| src/management/report-dates-and-filters.js | reportLine / receivedDay. Line normalization, inspection date and Riyadh receipt-day filters. |
| src/management/month-periods.js | monthlyWindow / monthlyReportIndex. Four month periods, comparison selection and point differences. |
| src/management/data/excel-template.json | STATION_XLSX. Four-sheet workbook structure, styles, headers and frozen panes. |
| src/management/monthly-scoring.js | stationPercentageExact / stationMonthSummary. Latest report per period, valid-period mean and point differences. |
| src/management/monthly-excel.js | buildStationMonthXlsx / saveStationMonthExcel. Four-sheet station workbook, numeric cells, formulas and details. |
| src/management/station-view.js | renderStationPerformance. Fixed line groups, newest updated station first and Excel action. |
| src/management/report-view.js | loadReportView / report cards. Loads complete answers on demand; unknown problem counts stay unknown until loaded. |
| src/management/xlsx-writer.js | xlsxCell / xlsxZipStore. Escaped XML, typed cells and dependency-free XLSX ZIP container. |
| src/management/report-excel.js | Single-inspection export. Fetches complete saved answers before two-sheet export and blocks duplicate download clicks. |
| src/management/refresh.js | captureManagementUiState / viewport anchor. Captures scroll at commit, retains the visible report and lets foreground navigation preempt polling. |
| src/management/bootstrap.js | Startup / visible-page refresh. Keeps ten-second polling while visible and skips hidden-page polling. |

## Build tools, tests and reference files

Build and tests are dependency-free. The build resolves aliases before serializing checklist JSON. Missing sources, duplicate alias keys and alias-to-alias chains are rejected. Immutable historical HTML snapshots remain protected by their stored hashes.

src is the editing master; dist is generated. The source ZIP includes both for reproducibility. Changes to rules must update canonical data, validation expectations and the current reference workbook together.

| File / folder | Responsibility |
| --- | --- |
| package.json / source-manifest.json | Commands, version, ordered fragments and output paths. |
| tools/build.mjs / template-data.mjs | Generate pages and resolve canonical checklist aliases. |
| tools/verify.mjs / check.mjs | Build/source checks and sequential eight-group test runner. |
| tools/test-scoring.mjs / serve.mjs | Compatibility scoring entry point / local static preview. |
| tests/models.mjs / receipt.mjs | Actual generated-script scoring and lookup behavior in controlled DOM. |
| tests/excel.mjs / archive.mjs / support.mjs | XLSX assertions, synthetic service and shared fixtures. |
| assets/ / docs/ | Banner inputs, current IT guide and verification evidence. |
| reference/Line_3/ and Lines_3_4_6/ | Original 352-point basis / current 358-point operational model. |
| reference/Line_5/ | Eleven unchanged original station workbooks. |
| reference/original* / dist/ | Preserved historical evidence / generated deployment outputs. |
| tests/responsiveness.mjs | Viewport anchor, startup ordering, hidden polling, deadlines, queued cancellation, lazy loading and complete exports. |
| tests/email.mjs | Thirty optional-mail contract and deadline checks; no real messages. |
| tests/pipeline.mjs | Generated submit handler through native local HTTP to management receipt and actual XLSX exports. |
| tests/employee-fixture.mjs / management-fixture.mjs | Reusable controlled-DOM fixtures with explicitly restricted injected transport. |

## Verification and practical limits

All eight local groups passed: 13,563 counted checks. VERIFICATION.json records the current source run. The final source ZIP is extracted and rebuilt, and its source/build and receipt checks are repeated. VERIFICATION_CLEAN.json records those two clean-extraction groups.

The local harness executes actual generated page scripts and management source with a controlled DOM. The pipeline test uses native HTTP and an isolated local service. These tests send zero external requests. XLSX checks inspect structure, types, formulas, cached values and complete answers.

Separately, one authorized temporary inspection completed a save/read/receipt cycle against the existing prototype service. It was removed after duplicate rejection was confirmed. This was a server/API test, not an actual browser or separate-device session.

No production deployment, company identity/role enforcement, supported-browser run, Microsoft Excel session, database migration or restore drill was completed. These remain company pilot acceptance items.

| Check group | Passed evidence |
| --- | --- |
| Source/build | 33: syntax, aliases, shared registry, protected original snapshots. |
| Employee models/flows | 12,718: 320 model cases, 1,296 parking combinations, 47 station renders, 14 simulated saves, seven failure cases. |
| Receipt lookup | 47: consumption, reopen, background/manual concurrency, stale drafts, duplicates and failures. |
| Excel/reference | 590 across seven export scenarios; four monthly sheets, typed values, mixed scales, blank reference. |
| Archive | 41 with 100,000 synthetic reports; cap seven, page 20, cache 12 and concurrency six. |
| Responsiveness | 27: viewport, horizontal scroll, lazy details, cancellation and deadlines. |
| Optional mail | 30: contract, recipients, origin, identity/transport/JSON deadlines. |
| Integrated HTTP pipeline | 77: four accepted reports, matching receipts, duplicate rejection, exports and exact mean 61.8644067796610%. |

The separate LIVE_SERVICE_VERIFICATION.json records 11 successful prototype checks plus confirmed cleanup of one temporary record. No email was sent.

## Prototype send and receipt | 25 October

The authorized live check used one cryptographically unique inspection ID and a clearly marked temporary QA employee. Reads, duplicate submission and cleanup were restricted to this test reference. Existing operational reports were not modified.

The generated employee submit handler saved 171 answers through the configured prototype route. Actual management read/normalization and receipt tracking then confirmed the same inspection ID. The matching acknowledgement was applied to the employee state in the controlled harness.

This validates the current API persistence and receipt logic. It does not validate browser preflights, company users, production policies or the cross-device user experience. Same-origin notices are independent from durable server receipt.

The mixed parking example retained exact score 345/354 and 97.4576271186441% despite rounded database percentage 97. All four P&R & Washrooms item labels survived storage. Mail was disabled throughout.

This live transaction is retained evidence from functional release 2.24 on 25 October. Management 2.21.1 changes attribution layout only; its functional script is byte-identical after normalizing the version comment. No additional live write is performed for this packaging update.

| Stage | Observed result |
| --- | --- |
| Before insertion | Exact temporary-ID query returned zero rows. |
| Employee save | HTTP 201; exactly one temporary report. |
| Management read | Same ID, complete answers and exact metadata returned. |
| Receipt controls | Received displayed; lookup consumed; both result actions available. |
| Duplicate attempt | HTTP 409 with database code 23505; no second report. |
| Cleanup | One temporary report deleted; final exact-ID read returned zero rows. |
| Evidence file | LIVE_SERVICE_VERIFICATION.json; no access key or operational record included. |

The one-time write verifier is not part of npm test and is not automatically rerun when IT builds this package.

## Pilot, release and maintenance

Company acceptance must cover supported Edge/Safari/Chrome, Microsoft Excel, real cross-device save/receipt, permissions, exact metadata preservation, duplicate IDs, network failures, representative archive search timings and successful backup restoration.

The 20 company cases in acceptance-tests.md remain pending. A local pass must not be relabeled as company sign-off. Record the environment, testers, date, unresolved issues and approval before operational rollout.

Maintenance sequence: retain the reviewed release and database backup; change the relevant source; update rules/reference/tests together; increase versions; run npm test; review outputs; test staging; deploy both pages together and record release hashes.

Keep historical saved reports immutable. Application rollback restores the prior reviewed deployment files. Any database migration or restoration is a separate company-controlled process.

Score code: employee/scoring.js. Monthly math: management/monthly-scoring.js. Canonical checklist: employee/data/templates.json, L3. Full file responsibilities: SOURCE_MAP.md.

| Company acceptance owner | Required completion |
| --- | --- |
| Management and coordinators | Approve checklist content, station targets and pilot outcomes. |
| IT platform owner | Approved hosting/service, company identity, paging, indexes and operational support. |
| Security owner | Server-enforced roles, validation, logging and approved data handling. |
| IT operations | Retention, tested backup restoration, monitoring and rollback record. |

Evidence in this guide is based on the delivered source and tests dated 25 October 2026. Local and prototype checks do not replace company sign-off.
