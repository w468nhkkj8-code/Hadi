# Line 5 reference material

The editable Line 5 checklist models are in ../../src/employee/data/. Historical completed workbooks are retained separately from the IT source export.
