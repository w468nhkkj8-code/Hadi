import { createHash } from 'node:crypto';
import {
  chmodSync,
  existsSync,
  lstatSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  renameSync,
  rmSync,
  writeFileSync,
} from 'node:fs';
import path from 'node:path';
import { gunzipSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';

const packageRoot = path.dirname(fileURLToPath(import.meta.url));
const destination = path.join(packageRoot, 'FLOW_PROJECT');
const expectedMapHash = '96caed98d00cff4817626370a0ec970296066d317a5afb8f5eeaa548aa5b2a78';

function sha256(bytes) {
  return createHash('sha256').update(bytes).digest('hex');
}

function resolveInside(root, relativePath) {
  if (typeof relativePath !== 'string' || relativePath.includes('\\')) {
    throw new Error('The file map contains an invalid relative path.');
  }
  const parts = relativePath.split('/');
  if (parts.some(part => !part || part === '.' || part === '..' || /[:\x00-\x1f]/u.test(part))) {
    throw new Error(`Unsafe file path in the map: ${relativePath}`);
  }
  let current = root;
  for (const part of parts) {
    current = path.join(current, part);
    if (existsSync(current) && lstatSync(current).isSymbolicLink()) {
      throw new Error(`A mapped path contains a symbolic link: ${relativePath}`);
    }
  }
  return current;
}

function readDeliveryFile(sourcePath, file) {
  const data = readFileSync(sourcePath);
  if (!file.delivery_encoding) return data;
  if (sha256(data) !== file.delivery_sha256) {
    throw new Error('A delivery copy failed its checksum: ' + file.delivery_path);
  }
  if (file.delivery_encoding === 'gzip') {
    return gunzipSync(data, { maxOutputLength: file.size_bytes });
  }
  if (file.delivery_encoding === 'digit-range-notation') {
    const escaped = "\\u0660-\\u0669\\u06F0-\\u06F9";
    const digits = String.fromCodePoint(0x660, 0x2d, 0x669, 0x6f0, 0x2d, 0x6f9);
    return Buffer.from(data.toString('utf8').replaceAll(escaped, digits));
  }
  throw new Error('Unsupported delivery encoding: ' + file.delivery_encoding);
}

function loadFiles() {
  const mapBytes = readFileSync(path.join(packageRoot, 'restore-map.json'));
  if (sha256(mapBytes) !== expectedMapHash) {
    throw new Error('restore-map.json is incomplete or has changed. Extract a complete delivery ZIP.');
  }
  const manifest = JSON.parse(mapBytes);
  const originals = new Set();
  const delivered = new Set();
  return manifest.files.map(file => {
    const target = file.original_path;
    const source = file.delivery_path;
    resolveInside(destination, target);
    const sourcePath = resolveInside(packageRoot, source);
    if (originals.has(target.toLowerCase()) || delivered.has(source.toLowerCase())) {
      throw new Error(`Duplicate file mapping: ${target}`);
    }
    originals.add(target.toLowerCase());
    delivered.add(source.toLowerCase());
    const bytes = readDeliveryFile(sourcePath, file);
    if (bytes.length !== file.size_bytes || sha256(bytes) !== file.sha256) {
      throw new Error(`The delivery copy is incomplete or has changed: ${source}`);
    }
    return { ...file, bytes };
  });
}

function verifyProject(files) {
  if (lstatSync(destination).isSymbolicLink() || !lstatSync(destination).isDirectory()) {
    throw new Error('FLOW_PROJECT already exists and is not a regular directory.');
  }
  const actualPaths = new Set();
  function listFiles(directory) {
    for (const item of readdirSync(directory, { withFileTypes: true })) {
      const fullPath = path.join(directory, item.name);
      if (item.isSymbolicLink()) {
        throw new Error('FLOW_PROJECT contains a symbolic link or later development files.');
      }
      if (item.isDirectory()) {
        listFiles(fullPath);
      } else {
        actualPaths.add(path.relative(destination, fullPath).split(path.sep).join('/'));
      }
    }
  }
  listFiles(destination);
  if (actualPaths.size !== files.length) {
    throw new Error('FLOW_PROJECT contains later changes. Keep it and extract this ZIP to another folder to restore again.');
  }
  for (const file of files) {
    const existing = resolveInside(destination, file.original_path);
    if (!actualPaths.has(file.original_path) || sha256(readFileSync(existing)) !== file.sha256) {
      throw new Error(`FLOW_PROJECT has a changed file: ${file.original_path}. Keep it and restore in another extracted folder.`);
    }
  }
}

function restoreProject(files) {
  const lockPath = path.join(packageRoot, '.flow-restore.lock');
  writeFileSync(lockPath, '', { flag: 'wx' });
  let temporary;
  try {
    if (existsSync(destination)) {
      verifyProject(files);
      console.log(`FLOW_PROJECT already matches all ${files.length} original files.`);
      return;
    }
    temporary = mkdtempSync(path.join(packageRoot, '.flow-restore-'));
    for (const file of files) {
      const target = resolveInside(temporary, file.original_path);
      mkdirSync(path.dirname(target), { recursive: true });
      writeFileSync(target, file.bytes, { flag: 'wx' });
      if (process.platform !== 'win32') {
        chmodSync(target, file.mode);
      }
      if (sha256(readFileSync(target)) !== file.sha256) {
        throw new Error(`Restored file verification failed: ${file.original_path}`);
      }
    }
    if (existsSync(destination)) {
      throw new Error('FLOW_PROJECT was created by another process. Keep that folder and retry in another extracted location.');
    }
    renameSync(temporary, destination);
    temporary = undefined;
    console.log(`Restored and verified ${files.length} original files in ${destination}`);
    console.log('Open FLOW_PROJECT/START_HERE.html, then follow it/DEPLOYMENT.md.');
  } finally {
    if (temporary) {
      rmSync(temporary, { recursive: true, force: true });
    }
    rmSync(lockPath, { force: true });
  }
}

try {
  const args = process.argv.slice(2);
  if (args.length > 1 || (args.length === 1 && args[0] !== '--check')) {
    throw new Error('Usage: node RESTORE_PROJECT.mjs [--check]');
  }
  const files = loadFiles();
  if (args[0] === '--check') {
    console.log(`Verified all ${files.length} delivery files against the restoration map.`);
  } else {
    restoreProject(files);
  }
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  console.error(`Flow project preparation failed. ${message}`);
  process.exitCode = 1;
}
